# ShockMaterials
Package for storing properties of materials for shock experiments
