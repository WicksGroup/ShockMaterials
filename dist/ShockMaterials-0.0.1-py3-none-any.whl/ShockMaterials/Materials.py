"""
Contains material properties that are interesting for shock
"""
